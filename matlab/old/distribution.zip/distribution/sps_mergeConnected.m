function prmLists = sps_mergeConnected(contigs, prmSpecs, aligns, vSets, eSets, tolerance);

numComps = size(vSets,1);   numContigs = size(contigs,1);   
tolRange = round([-tolerance*10:tolerance*10]);

prmLists = cell(numComps,4);
prmsToKeep = cell(numContigs,1);

for i=1:numComps
    numVerts = size(vSets{i,1},2);   numEdges = size(eSets{i,1},2);
    vertices = vSets{i,1};           edges = aligns(eSets{i,1},:);

    absShifts = getAbsoluteShifts(edges, 2*tolerance, 0);
    
    maxMass = round(max(absShifts(vertices)'+[contigs{vertices,5}])*10); 
    matchScores = zeros(maxMass,1);   
    for j=1:numVerts   v = vertices(j);
        minPrm = min(find(prmSpecs{v,1}(:,2)>0));    prmSpecs{v,2} = minPrm;
        maxPrm = max(find(prmSpecs{v,1}(:,2)>0));    prmSpecs{v,3} = maxPrm;   
        prmSpecs{v,4} = round(absShifts(v)*10);      prmSpecs{v,5} = [];       prmSpecs{v,6} = min([0;prmSpecs{v,1}(:,2)]);
        matchRange = [prmSpecs{v,4}+minPrm:prmSpecs{v,4}+maxPrm];
        matchScores(matchRange) = matchScores(matchRange) + prmSpecs{v,1}(minPrm:maxPrm,2);  
    end

    maxIdx = find(matchScores==max(matchScores) & matchScores>0);
    while ~isempty(maxIdx) & matchScores(maxIdx(1))>0.1
        if size(maxIdx,1)>1 
            maxIdx = selectPRM([maxIdx matchScores(maxIdx)], round(10*tolerance));
        end;

        matchSpecs=0;  
        prmScore = 0;
        for j=1:numVerts   v = vertices(j);    prmIdx = maxIdx - prmSpecs{v,4};
            if prmIdx<prmSpecs{v,2} | prmIdx>prmSpecs{v,3} continue; end;
			prmScore   = prmScore + prmSpecs{v,1}(prmIdx,2);   
            if (prmSpecs{v,1}(prmIdx,2)<=0) continue; end;
            matchSpecs = matchSpecs + 1;  

            symIdx = round(contigs{v,5}*10-10-prmIdx);
            remIdx = [prmIdx-550:prmIdx+550 symIdx-10:symIdx+10]';
            
            remIdx = remIdx(find(remIdx>=prmSpecs{v,2} & remIdx<=prmSpecs{v,3}));
            remIdx = setdiff(remIdx,prmSpecs{v,5});
            
            prmSpecs{v,5} = [prmSpecs{v,5}; remIdx];
            matchScores(prmSpecs{v,4}+remIdx) = matchScores(prmSpecs{v,4}+remIdx) - prmSpecs{v,1}(remIdx,2);

            prmSpecs{v,1}(remIdx,2) = prmSpecs{v,6};  
            matchScores(prmSpecs{v,4}+remIdx) = matchScores(prmSpecs{v,4}+remIdx) + prmSpecs{v,6};
        end
        if matchSpecs>1 prmLists{i,1} = [prmLists{i,1}; maxIdx/10 prmScore]; end;
        maxIdx = find(matchScores==max(matchScores) & matchScores>0);
        tmp = prmLists{i,1};
    end;

    prmLists{i,2} = absShifts(vertices)';                           prmLists{i,2} = prmLists{i,2}(find(prmLists{i,2}>tolerance));
    
    prmLists{i,3} = absShifts(vertices)'+[contigs{vertices,5}];   
    prmLists{i,4} = mean( prmLists{i,3}( find(prmLists{i,3}>max(prmLists{i,3})-10) ) );
    prmLists{i,3} = prmLists{i,3}(find(prmLists{i,3}<max(prmLists{i,3})-56));

end


function prmMass = selectPRM(prmSpec, tolerance)

numPRMs = size(prmSpec,1); groupEnd=1;
while groupEnd<numPRMs & prmSpec(groupEnd+1,1)-prmSpec(groupEnd,1)-tolerance<=1e-5  groupEnd=groupEnd+1; end;
prmSpec = prmSpec(1:groupEnd,:);
numPRMs = groupEnd;
if numPRMs==1 prmMass=prmSpec(1,1); return; end

arraySpec = zeros(prmSpec(numPRMs,1)-prmSpec(1,1)+2*tolerance+1,1); 
arrayIndices = prmSpec(:,1)-prmSpec(1,1)+tolerance+1;               
arraySpec(arrayIndices) = prmSpec(:,2);
lpSpec = prmSpec;
for i=1:numPRMs lpSpec(i,2)=sum(arraySpec(arrayIndices(i)-tolerance:arrayIndices(i)+tolerance)); end;
weightedCenter = sum( lpSpec(:,1).*(lpSpec(:,2)/sum(lpSpec(:,2))) );
prmSpec = lpSpec(find(lpSpec(:,2)==max(lpSpec(:,2))),:);
if size(prmSpec,1)==1 prmMass=prmSpec(1,1); return; end

distToCenter = abs(prmSpec(:,1)-weightedCenter);
prmSpec = prmSpec(find(distToCenter==min(distToCenter)),:);
prmMass = prmSpec(1,1); 
