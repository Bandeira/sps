function [pair1, pair2] = sps_getPrmShiftsScore(prmList1, mhMass1, prmList2, mhMass2, tolerance, pmTol, smallJumps)

pair1=[]; pair2=[];

prmCount1 = size(prmList1,1);               prmCount2 = size(prmList2,1);
idx1 = prmList1(1:prmCount1,1);             idx2 = prmList2(1:prmCount2,1);
mhMass1 = round(10*mhMass1);                mhMass2 = round(10*mhMass2);       
tolRange = [-tolerance*10:tolerance*10]';   pmTolRange = [-pmTol*10:pmTol*10]';
middle = round((mhMass1-mhMass2)/2);    

m1 = repmat(prmList1(1:prmCount1,1), 1, prmCount2);
m2 = repmat(prmList2(1:prmCount2,1)', prmCount1, 1);
shifts = unique ( round((m1-m2)*10) );

smallJumps = round(10*smallJumps);
smallJumpsPM = unique( repmat(smallJumps,1,size(pmTolRange,1)) + repmat(pmTolRange', size(smallJumps,1), 1) );
smallJumpsPM = round(smallJumpsPM);  maxSmallJumpPM = max(smallJumpsPM);   
smallJumpsPM = [-smallJumpsPM; pmTolRange; smallJumpsPM];

smallJumps = unique( repmat(smallJumps,1,size(tolRange,1)) + repmat(tolRange', size(smallJumps,1), 1) );
smallJumps = round(smallJumps);  maxSmallJump = max(smallJumps);   
smallJumps = [-smallJumps; tolRange; smallJumps];
shifts = unique([shifts; smallJumps; mhMass1-mhMass2+smallJumps; tolRange]);  
shifts = shifts(find(shifts+mhMass2>=3722 & shifts<=(mhMass1-3722)));  

counts = histc(reshape(round((m1-m2)*10), prmCount1*prmCount2, 1), shifts);
offset = mhMass2;  counts2 = zeros(offset+mhMass1,1);   
for i=1:size(shifts,1)
    counts2(offset+shifts(i)+tolRange) = counts2(offset+shifts(i)+tolRange)+counts(i);
end

shiftPairs = getShiftPairs([shifts counts2(offset+shifts)], middle, pmTol);  
shiftPairs = shiftPairs(find(shiftPairs(:,3) > max(shiftPairs(:,3))/5),:);
if size(shiftPairs,1)==0 pair1 = []; return; end;

toKeep = ones(mhMass1+mhMass2,1);                
sjRange = [-maxSmallJump:maxSmallJump];            sjRangePM = [-maxSmallJumpPM:maxSmallJumpPM];
smallJumpsArray = zeros(maxSmallJump*2+1,1);       smallJumpsPMArray = zeros(maxSmallJumpPM+1,1);
smallJumpsArray(maxSmallJump+smallJumps+1) = 1;    smallJumpsPMArray(maxSmallJumpPM+smallJumpsPM+1) = 1;
shiftsArray = zeros(mhMass2+mhMass1,1);            shiftsArray(mhMass2+unique(shiftPairs(:,1:2))) = 1;

limits1 = [0; mhMass1];   limits2 = [0; mhMass2];
for i=1:size(limits1,1)                                                                 
    for j=1:size(limits2,1)
        baseShift = limits1(i)-limits2(j);
        if limits1(i)>0 & limits2(j)>0      
            okRange = mhMass2+sjRangePM+baseShift;   jumps = smallJumpsPMArray;
        else
            okRange = mhMass2+sjRange+baseShift;     jumps = smallJumpsArray;  
        end
        idx=find(okRange>3722 & okRange<mhMass2+mhMass1-3722);       
        toKeep(okRange(idx)) = toKeep(okRange(idx)) .* jumps(idx);  
    end
end;
pairsToKeep = toKeep(shiftPairs(:,1:2)+mhMass2);
shiftPairs = shiftPairs(find(pairsToKeep(:,1)==1 & pairsToKeep(:,2)==1),:);
if isempty(shiftPairs) pair1=[]; return; end;


shifts = unique(shiftPairs(:,1:2));    mhMass1 = mhMass1/10; mhMass2 = mhMass2/10;
scores = zeros(size(shifts,1),3);      prmIndices = cell(size(scores,1),1);

for j=1:size(shifts)
    scores(j,1) = shifts(j);
    [scores(j,2), prmIndices{j,1}] = sps_scoreOverlap(prmList1, mhMass1, prmList2, mhMass2, shifts(j)/10, tolerance);
end;

pair1=[]; pair2=[];

scorePairs = getShiftPairs(scores(:,1:2), middle, pmTol);
if isempty(scorePairs) return; end;
scorePairs(:,1:2) = scorePairs(:,1:2)/10;

best = scorePairs(find(scorePairs(:,3)==max(scorePairs(:,3))),:);
pair1 = bestPair(best, middle/10, pmTol);

scorePairs = scorePairs(find( scorePairs(:,1)<pair1(1,1)-pmTol | scorePairs(:,1)>pair1(1,1)+pmTol ),:);
scorePairs = scorePairs(find( scorePairs(:,1)<pair1(1,2)-pmTol | scorePairs(:,1)>pair1(1,2)+pmTol ),:);  if isempty(scorePairs) return; end;
scorePairs = scorePairs(find( scorePairs(:,2)<pair1(1,1)-pmTol | scorePairs(:,2)>pair1(1,1)+pmTol ),:);  if isempty(scorePairs) return; end;
scorePairs = scorePairs(find( scorePairs(:,2)<pair1(1,2)-pmTol | scorePairs(:,2)>pair1(1,2)+pmTol ),:);  if isempty(scorePairs) return; end;

best = scorePairs(find(scorePairs(:,3)==max(scorePairs(:,3))),:);
pair2 = bestPair(best, middle/10, pmTol);


function shiftPairs = getShiftPairs(shifts, middle, pmTol)
pmTolRange = -10*pmTol:10*pmTol;

offset = -min(shifts(:,1))+1+max(pmTolRange);   numEntries = offset + max(shifts(:,1)) + max(pmTolRange);
shiftsArray = zeros(numEntries,1);
shiftsArray(shifts(:,1)+offset)=shifts(:,2);

shiftPairs = [shifts(:,1) zeros(size(shifts,1),2)];    toKeep = ones(size(shiftPairs,1),1);
for i=1:size(shiftPairs,1)
    idx = (2*middle-shiftPairs(i,1))+offset+pmTolRange;   idx = idx(find(idx>0 & idx<numEntries));
    if isempty(idx) toKeep(i)=0; continue; end;
    [M, idxM] = max(shiftsArray(idx));
    shiftPairs(i,2)=(idx(idxM(1))-offset);
    shiftPairs(i,3)=shifts(i,2)+M;
end;
shiftPairs = shiftPairs(find(toKeep==1),:);


function pair = bestPair(pairs, middle, pmTol)
numPairs = size(pairs,1);
for i=1:numPairs
    idx = find(pairs(i+1:numPairs,2)==pairs(i,1) & pairs(i+1:numPairs,1)==pairs(i,2));
    if ~isempty(idx) 
        pair = [pairs(i,:); pairs(i+idx,:)]; return; 
    end;
end
diffs = abs(pairs(:,1)+pairs(:,2)-2*middle);
[d, idx] = min(diffs);
pair = [pairs(idx(1),:); pairs(idx(1),[2 1 3])];
