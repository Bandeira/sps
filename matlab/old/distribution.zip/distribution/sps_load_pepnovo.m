function prmSpectraAll = sps_load_pepnovo(msmsSpectra, dtaFilenames, inDir);

numSpecs = size(msmsSpectra,1);   prmSpectraAll = cell(numSpecs,7);
fid = fopen(dtaFilenames,'r');
peptideProtPos = -10;
for i=1:numSpecs
    prmSpectraAll{i,1} = msmsSpectra{i,1};
    prmSpectraAll{i,5} = msmsSpectra{i,3};
    prmSpectraAll{i,6} = peptideProtPos;  peptideProtPos = peptideProtPos-10; 
    prmSpectraAll{i,7} = msmsSpectra{i,5};
    
    filename = sprintf('%sprm%s',inDir,fgetl(fid));
    prmSpectraAll{i,3} = sps_load_peaklist(filename);
end
fclose(fid);
