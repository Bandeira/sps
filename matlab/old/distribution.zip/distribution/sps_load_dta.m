function msmsSpectra = sps_load_dta(dtaFilenames,inDir)
%
%  Loads all the MS/MS spectra identified in idx (old - from protein protIdx)
%  data{i,1} - filename index
%  data{i,2}(:,2) - spectrum peaks. Each entry is [m/z intensity]
%  data{i,3} - totalMass
%  data{i,4} - charge
%  data{i,5} - amino acid sequence
%

fid = fopen(dtaFilenames,'r');
if fid<=0 fprintf(1,'Error opening %f!\n',dtaFilenames); return; end;
idx = {};   line = fgetl(fid);
while size(line,2)>1
    idx = [idx; {line}];
    line = fgetl(fid);
end;
fclose(fid);

numPeps = size(idx,1);   msmsSpectra = cell(numPeps,5);
for i=1:numPeps
    msmsSpectra{i,1} = i;
    tmp = sps_read_dta(sprintf('%s%s',inDir,idx{i}));
    msmsSpectra(i,2) = tmp(1,1);
    msmsSpectra{i,3} = tmp{1,2}(1,1);
    msmsSpectra{i,4} = tmp{1,2}(2,1);
    msmsSpectra{i,5} = '';
    if mod(i,100)==0 fprintf(1,'%d,',i); end;
    if mod(i,1000)==0 fprintf(1,'\n,',i); end;
end;
