function sps_pepnovo_batch(filenameI)

fidI = fopen(filenameI,'r');  if fidI<0 fprintf('Unable to open %s!\n',filenameI); return; end;
fidO = fopen('dta\\run.bat','w');  if fidO<0 fprintf('Unable to open dta\\run.bat!\n'); fclose(fidI); return; end;

while ~feof(fidI)
    line = fgetl(fidI);
    
    if ~isempty(line) 
        fprintf(fidO,'..\\pepnovo_prms -m ..\\pepnovo.params -dta %s > prm%s\n',line,line); 
    end
end;

fclose(fidO);   fclose(fidI);
