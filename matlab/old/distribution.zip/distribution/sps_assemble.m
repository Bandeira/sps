function [vSets, eSets] = sps_assemble(aligns)

numPeptides = size(unique(aligns(:,[1 2])),1);    vSets = cell(numPeptides,1);
contigsIdx = zeros(max(max(aligns(:,[1 2]))),1);  numContigSets = 0;

szAligns = size(aligns,1);
toProcess = ones(szAligns,1); idxAligns = [1:szAligns]';   tensLeft = floor(szAligns/10000);
curTime = 0; tic;
for idx=1:szAligns
    i = aligns(idx,1);    j = aligns(idx,2);
    
    if contigsIdx(i)>0 & contigsIdx(j)>0 & contigsIdx(i)==contigsIdx(j)
        continue; 
    end;  

    idxI = contigsIdx(i);    idxJ = contigsIdx(j);
    
    if idxI==0 & idxJ==0 numContigSets=numContigSets+1; vSets{numContigSets,1} = [i j];   contigsIdx([i j])=numContigSets;   
    else if idxI==0 vSets{idxJ,1} = [vSets{idxJ,1} i];  contigsIdx(i)=idxJ;  
        else if idxJ==0 vSets{idxI,1} = [vSets{idxI,1} j];  contigsIdx(j)=idxI;
            else if idxI~=idxJ 
                    vSets{idxI,1} = unique([vSets{idxI,1} vSets{idxJ,1}]); 
                    contigsIdx(vSets{idxJ,1}) = idxI;
                    if idxJ<numContigSets
                        vSets{idxJ,1} = vSets{numContigSets,1}; 
                        contigsIdx(vSets{numContigSets,1}) = idxJ;
                    end
                    numContigSets=numContigSets-1;
                end;
            end;
        end;
    end;

    curTensLeft=floor(size(idxAligns,1)/10000); 
    if curTensLeft<tensLeft 
        t=toc; curTime=curTime+t; tic;
        fprintf(1,'%d aligns left, current 10000 took %.1f secs, ETA: %.1f secs...\n',size(idxAligns,1),t,curTensLeft*curTime/10000); tensLeft=curTensLeft; 
    end;
end; 
vSets = vSets(1:numContigSets,:);
edgesSet = contigsIdx(aligns(:,1));   eSets = cell(size(vSets,1),1);
for i=1:size(vSets,1)  eSets{i} = find(edgesSet==i)'; end;
