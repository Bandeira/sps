function [vSets, eSets,trigVerts] = filterDirection3(contigs, aligns, tolerance)

szAligns = size(aligns,1);   edgeScores = aligns(:,4);

vertices = unique([aligns(:,1); aligns(:,2)]);    numVertices = size(vertices,1);
renameVec = zeros(max(vertices),1);               renameVec(vertices) = [1:numVertices];
aligns = [renameVec(aligns(:,1:2)) aligns(:,3:size(aligns,2))];
contigs = contigs(vertices,:);

for i=1:szAligns
    if aligns(i,1)>aligns(i,2) 
        aligns(i,1:2) = [aligns(i,2) aligns(i,1)];
        if aligns(i,3)>0 aligns(i,3) = -aligns(i,3); end;
    end
end
[foo, idxSaligns] = sortrows(aligns,1:3);   aligns=aligns(idxSaligns,:);   edgeScores=edgeScores(idxSaligns,:);   clear foo;


edges = cell(numVertices,numVertices);  
adjacency  = cell(numVertices,1);       
alignmentScores = zeros(size(unique(aligns(:,1:2),'rows'),1),3);   
alignmentScoresIdx = 1;
i=1;
while i<szAligns
    v1 = aligns(i,1);   v2 = aligns(i,2);
    if aligns(i+1,1)~=v1 | aligns(i+1,2)~=v2 i=i+1; continue; end;  
    alignmentScores(alignmentScoresIdx,1:2)=[v1 v2];
    if i+2<=szAligns & aligns(i+2,1)==v1 & aligns(i+2,2)==v2
        alignmentScores(alignmentScoresIdx,:)=max(edgeScores(i:i+2));   
        if abs(aligns(i,3))<=tolerance edges{v1,v2}=[i+1 i+2]; else edges{v1,v2}=[i i+1]; end;
        i=i+3;
    else 
        edges{v1,v2} = [i i+1];  alignmentScores(alignmentScoresIdx,:)=max(edgeScores(i:i+1));   i=i+2;
    end
    
    adjacency{v1} = [adjacency{v1}; v2];
    adjacency{v2} = [adjacency{v2}; v1];
end

idx = [edges{:,:}];
[idxGood, idxZero, idxEqualLR] = separateEdges( aligns(idx,:), tolerance );
degenerateEdges = zeros(szAligns,1);   degenerateEdges(idx([idxZero;idxEqualLR])) = 1;

trigSets = {};                    
trigVerts = [];                  
trigScores = [];                 
for v1=1:numVertices
    adj_v1 = adjacency{v1};   adj_v1 = adj_v1(find(adj_v1>v1));  
    for j=1:size(adj_v1,1)
        v2 = adj_v1(j);
        adj_v1v2 = intersect(adjacency{v1},adjacency{v2});
        adj_v1v2 = adj_v1v2(find(adj_v1v2>v2));
        for k=1:size(adj_v1v2,1)
            v3 = adj_v1v2(k);
            e12 = [aligns(edges{v1,v2},:) edges{v1,v2}']; 
            e13 = [aligns(edges{v1,v3},:) edges{v1,v3}'];
            e23 = [aligns(edges{v2,v3},:) edges{v2,v3}'];
            
            [t1,t2] = getTriangles(e12,e13,e23,4*tolerance);
            if isempty(t1) continue; end;
            trigSets = [trigSets; {t1} {t2}];    trigVerts = [trigVerts; [v1 v2 v3]];   trigScores = [trigScores; sum(edgeScores(t1(:,6)))];
        end
    end
end
numTrigs = size(trigScores,1);
[foo,idxS] = sort(trigScores);   idxS=idxS(numTrigs:-1:1);   trigScores = trigScores(idxS);
trigSets=trigSets(idxS,:);       trigVerts = trigVerts(idxS,:);


vSets = {};    eSets = {};    numComps=0;
membership = zeros(numVertices,1);    
edgeMembership = zeros(szAligns,1);   

while numTrigs>0
    i=1;
    while i<=numTrigs
        comps = membership(trigVerts(i,:));    [compsS, idxS] = sort(comps);
        if compsS(3)==0    
            vSets = [vSets; {[trigVerts(i,:)]}];
            eSets = [eSets; {trigSets{i,1}(:,6)'} {trigSets{i,2}(:,6)'}];
            numComps = numComps+1;
            membership(trigVerts(i,:))=numComps;
            edgeMembership(eSets{numComps,1})=1;
            edgeMembership(eSets{numComps,2})=2;
            processedTrigs = [i];   processedComp = numComps;
            break;
        end
        
        if compsS(1)==0 & compsS(2)==compsS(3)   
            c = compsS(3);   newV = trigVerts(i,idxS(1));

            eMemb = edgeMembership(trigSets{i,1}(:,6));  setDir1 = max(eMemb);   newEdges1 = find(eMemb==0);   
            if degenerateEdges(trigSets{i,1}(find(eMemb>0),6))==1 i=i+1; continue; end;   
            
            eMemb = edgeMembership(trigSets{i,2}(:,6));  setDir2 = max(eMemb);   newEdges2 = find(eMemb==0);   
            if setDir1==setDir2 | size(newEdges1,1)~=2 | size(newEdges2,1)~=2
                fprintf(1,'ERROR: directions should be unique!!\n');
                vSets = {};   eSets = {};   return;
            end
            eSets{c,setDir1}=[eSets{c,setDir1} trigSets{i,1}(newEdges1,6)'];   edgeMembership(trigSets{i,1}(newEdges1,6))=setDir1;
            eSets{c,setDir2}=[eSets{c,setDir2} trigSets{i,2}(newEdges2,6)'];   edgeMembership(trigSets{i,2}(newEdges2,6))=setDir2;

            vSets{c} = [vSets{c} newV];
            membership(newV) = c;

            processedTrigs = [i];   processedComp = c;
        end
        
        if compsS(1)>0 & (compsS(1)==compsS(2) | compsS(2)==compsS(3))   
            c2 = compsS(2);   v2=trigVerts(i,idxS(2));   
            if c2==compsS(1)
                c1 = compsS(3);  v1=trigVerts(i,idxS(1));  vNew=trigVerts(i,idxS(3));
            else
                c1 = compsS(1);  v1=trigVerts(i,idxS(3));  vNew=trigVerts(i,idxS(1));
            end
            if degenerateEdges(find(aligns(:,1)==min(v1,v2) & aligns(:,2)==max(v1,v2)))==1 i=i+1; continue; end; 
            
            setBoth = intersect(vSets{c1}',adjacency{vNew}); 
            if isempty(setBoth) i=i+1; continue; end;        
            
            hyp1 = intersect(adjacency{v1},setBoth);   hyp2 = intersect(adjacency{v2},setBoth);
            hyp = [v1*ones(size(hyp1)) hyp1; v2*ones(size(hyp2)) hyp2];
            for j=1:size(hyp,1)
                if degenerateEdges(find(aligns(:,1)==min(vNew,hyp(j,2)) & aligns(:,2)==max(vNew,hyp(j,2))))==1 continue; end; 
                trigTry = sort([hyp(j,1) vNew hyp(j,2)]);
                trigTryIdx = find(trigVerts(:,1)==trigTry(1) & trigVerts(:,2)==trigTry(2) & trigVerts(:,3)==trigTry(3));
                if isempty(trigTryIdx) continue; end;

                [trigMergeDir,trigMergeSym] = intersectEdgesets(trigSets{i,1},trigSets{i,2},trigSets{trigTryIdx,1},trigSets{trigTryIdx,2},tolerance);
                if isempty(trigMergeDir) continue; end;
                
                idx2 = find(trigMergeDir(:,1)==min(v1,v2) & trigMergeDir(:,2)==max(v1,v2));  
                idx1 = find(trigMergeDir(:,1)==min(vNew,hyp(j,2)) & trigMergeDir(:,2)==max(vNew,hyp(j,2)));
                if c2<c1  
                    mergeDirs = edgeMembership(trigMergeDir([idx2 idx1],6))';   
                    processedComp = c2; otherComp = c1;
                else
                    mergeDirs = edgeMembership(trigMergeDir([idx1 idx2],6))';
                    processedComp = c1; otherComp = c2;
                end
                mergeDirs = [mergeDirs; mod(mergeDirs,2)+1];  
                
                newEdgesD = find(edgeMembership(trigMergeDir(:,6))==0);
                newEdgesS = find(edgeMembership(trigMergeSym(:,6))==0);
                
                vSets{processedComp} = [vSets{processedComp} vSets{otherComp}];
                eSets{processedComp,mergeDirs(1,1)} = [eSets{processedComp,mergeDirs(1,1)} eSets{otherComp,mergeDirs(1,2)} trigMergeDir(newEdgesD,6)'];
                eSets{processedComp,mergeDirs(2,1)} = [eSets{processedComp,mergeDirs(2,1)} eSets{otherComp,mergeDirs(2,2)} trigMergeSym(newEdgesS,6)'];
                membership(vSets{otherComp}) = processedComp;                       
                edgeMembership(eSets{otherComp,mergeDirs(1,2)}) = mergeDirs(1,1);   
                edgeMembership(trigMergeDir(newEdgesD,6)) = mergeDirs(1,1);
                edgeMembership(eSets{otherComp,mergeDirs(2,2)}) = mergeDirs(2,1);
                edgeMembership(trigMergeSym(newEdgesS,6)) = mergeDirs(2,1);
                
                if otherComp<numComps  
                    vSets{otherComp} = vSets{numComps};   eSets(otherComp,:) = eSets(numComps,:);   membership(vSets{numComps}) = otherComp;
                end
                numComps=numComps-1;   vSets=vSets(1:numComps,:);   eSets = eSets(1:numComps,:);
                
                processedTrigs = [i trigTryIdx];
                break;
            end
        end
        
        if ~isempty(processedTrigs)
            trigMship = membership(trigVerts);   if size(trigVerts,1)==1  trigMship=trigMship'; end;
            extraTrigs = setdiff(find(trigMship(:,1)==processedComp & trigMship(:,2)==processedComp & trigMship(:,3)==processedComp),processedTrigs');
            
            for j=1:size(extraTrigs,1)
                degOk = find(degenerateEdges(trigSets{extraTrigs(j),1}(:,6))==0);  
                eMemb1 = edgeMembership(trigSets{extraTrigs(j),1}(:,6));  setDir1 = max(eMemb1(degOk));   newEdges1 = find(eMemb1==0);  
                degOk = find(degenerateEdges(trigSets{extraTrigs(j),2}(:,6))==0);
                eMemb2 = edgeMembership(trigSets{extraTrigs(j),2}(:,6));  setDir2 = max(eMemb2(degOk));   newEdges2 = find(eMemb2==0);  

                if (isempty(newEdges1) | isempty(newEdges2)) | (isempty(setDir1) | isempty(setDir2)) | (setDir1==0 | setDir2==0)
                   continue; 
               end;   

               if setDir1==setDir2   
                    i=numTrigs+1; 
                    break;
               end

               eSets{processedComp,setDir1}=[eSets{processedComp,setDir1} trigSets{extraTrigs(j),1}(newEdges1,6)'];   edgeMembership(trigSets{extraTrigs(j),1}(newEdges1,6))=setDir1;
               eSets{processedComp,setDir2}=[eSets{processedComp,setDir2} trigSets{extraTrigs(j),2}(newEdges2,6)'];   edgeMembership(trigSets{extraTrigs(j),2}(newEdges2,6))=setDir2;
            end
            
            processedTrigs = [processedTrigs extraTrigs'];
            break;
        end
        
        i=i+1;
    end
    if i>numTrigs
        break;
    end
    
    kept = setdiff([1:numTrigs]',processedTrigs');
    trigSets = trigSets(kept,:);    trigVerts = trigVerts(kept,:);   trigScores = trigScores(kept);
    numTrigs = size(trigSets,1);    processedTrigs = [];
end

for i=1:size(vSets,1)  vSets{i} = vertices(vSets{i})'; end;
for i=1:size(eSets,1)  eSets{i,1} = idxSaligns(eSets{i,1})';   eSets{i,2} = idxSaligns(eSets{i,2})'; end;



function [setRdir,setRsym] = intersectEdgesets(set1dir,set1sym,set2dir,set2sym,tolerance)
match = repmat(set1dir([1 1 1 2 2 2 3 3 3]',1:3),2,1) - [repmat(set2dir(:,1:3),3,1); repmat(set2sym(:,1:3),3,1)];
idx = find(match(:,1)==0 & match(:,2)==0 & abs(match(:,3))<=tolerance);

if isempty(idx) | max(size(idx))>1
    setRdir=[]; setRsym=[]; return;
end

if idx>9
    idx = idx-9;
    tmp = set2dir;   set2dir=set2sym;   set2sym=tmp;
end
idx = mod(idx,3);  if idx==0 idx=3; end;

setRdir=[set1dir; set2dir(1:idx-1,:); set2dir(idx+1:3,:)];
idx2=find(set2sym(:,1)==set2dir(idx,1) & set2sym(:,2)==set2dir(idx,2)); setRsym=[set1sym; set2sym(1:idx2-1,:); set2sym(idx2+1:3,:)];
