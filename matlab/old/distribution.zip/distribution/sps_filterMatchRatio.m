function ratios = sps_filterMatchRatio(contigs, aligns, tolerance, pmTol)

szAligns = size(aligns,1);   done = zeros(szAligns,1);   ratios = zeros(szAligns,3);  
for i=1:szAligns
    if mod(i,5000)==0 fprintf(1,'( %d / %d )\n',i,szAligns);
    else if mod(i,1000)==0 fprintf(1,'X');
        else if mod(i,100)==0 fprintf(1,'.'); end; end; end;
        
    if done(i)==1 continue; else done(i)=1; end;
    middle = round(10*(contigs{aligns(i,1),5} - contigs{aligns(i,2),5})/2)/10;

    symShift = 2*middle-aligns(i,3);
    if symShift<=0
        idxSym = find(aligns(:,1)==aligns(i,2) & aligns(:,2)==aligns(i,1) & abs(aligns(:,3)+symShift)<=pmTol);
    else
        idxSym = find(aligns(:,1)==aligns(i,1) & aligns(:,2)==aligns(i,2) & abs(aligns(:,3)-symShift)<=pmTol);
    end
    if isempty(idxSym) continue; end;
    idxSym = idxSym(find(idxSym~=i));
    if isempty(idxSym) continue; else done(idxSym)=1; curAligns = aligns([i; idxSym],:); end;

    [ratios(i,1) ratios(i,2)] = sps_getMatchRatio(contigs, curAligns, tolerance);
    ratios(i,3) = min(contigs{aligns(i,1),5}-aligns(i,3),contigs{aligns(i,2),5});
    
    if curAligns(1,1)==curAligns(2,1) ratios(idxSym,:) = ratios(i,:); else ratios(idxSym,:) = ratios(i,[2 1 3]); end;
end
