%
%  Matlab code distribution
%

% Input parameters
dtaFilelist = 'dta\\filelist.txt';
peakTolerance = 0.5;
pmTolerance = 1;
alignsEnforceAA = 2;
ratioThreshold = 0.5;
prmPenalty = -10;      % Used for genPRMspecs
outputSeqsFile = 'results.txt';

% Example specs for sequence LIVTQTMKG

%
% Step 1: Load MS/MS data
%
msmsSpectra = sps_load_dta(dtaFilelist,'dta\\');   numSpecs = size(msmsSpectra,1);

sps_pepnovo_batch(dtaFilelist); cd('dta'); [foo1,foo2]=dos('run.bat'); cd('..');
prmSpectraAll = sps_load_pepnovo(msmsSpectra, dtaFilelist, 'dta\\');   
prmSpectra = prmSpectraAll;  numPeaks = zeros(numSpecs,1);
for j=1:numSpecs
    if isempty(prmSpectra{j,3}) continue; end;
    idx = find(prmSpectra{j,3}(:,2)>0 & prmSpectra{j,3}(:,1)>=50 & prmSpectra{j,3}(:,1)<=prmSpectra{j,5}-50);
    numPeaks(j) = size(idx,1);
    prmSpectra{j,3} = prmSpectra{j,3}(idx,:);
end
prmSpectra = prmSpectra(find(numPeaks>=10),:);

%
% Step 2: Compute pairwise alignments
%
aligns = sps_getPairAligns(prmSpectra, peakTolerance, pmTolerance, alignsEnforceAA);
ratios = sps_filterMatchRatio(prmSpectra, aligns, peakTolerance, 2*pmTolerance);
alignsF = aligns(find(ratios(:,1)>=ratioThreshold & ratios(:,2)>=ratioThreshold),:);
alignsFT = sps_filterTrigs(alignsF, peakTolerance);

%
% Step 4: Get contigs - assembleE, filterDirections, denovoMA
%
[vertices, edges] = sps_assemble(alignsFT);
numContigs = size(vertices,1);   verticesD = cell(numContigs,1);   edgesD = cell(numContigs,1);   sequences = cell(numContigs,1);
completeSpecs = sps_genCompleteSpecs(prmSpectra,vertices,prmPenalty,peakTolerance);
resFid = fopen(outputSeqsFile,'w');
for i=1:numContigs
    % Filter directions
    [verticesD{i}, edgesD{i}] = sps_filterDirection(prmSpectra, alignsFT, peakTolerance);
    sequences{i} = cell(size(verticesD{i},1),1);
    
    % merge completeSpecs
    fprintf(resFid,'Contig %d\n',i);
    for s=1:size(verticesD{i,1},1)
        consensus1 = sps_mergeConnected(prmSpectra,completeSpecs,alignsFT,{verticesD{i}{s}},{edges{i,1}(edgesD{i,1}{s,1})},peakTolerance);
        consensus2 = sps_mergeConnected(prmSpectra,completeSpecs,alignsFT,{verticesD{i}{s}},{edges{i,1}(edgesD{i,1}{s,2})},peakTolerance);
        sequences{i}{s} = sps_denovoMA(consensus1, consensus2, mean([consensus1{1,4} consensus2{1,4}]), peakTolerance);
        fprintf(resFid,'Subcontig %d\t %s\n',s,sequences{i}{s});
	end;
    fprintf(resFid,'\n');
end
fclose(resFid);
