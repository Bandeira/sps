function [score, prmIndex] = sps_scoreOverlap(prmList1, mhMass1, prmList2, mhMass2, shift, tolerance)
% function [score, prmIndex] = sps_scoreOverlap(prmList1, mhMass1, prmList2, mhMass2, shift, scoreFunIdx, tolerance)
%
%  Compute the score of an overlap - same as score overlap but for experimental data
% 
%  Same as getPrmShiftScore functions but coded seperately to maintain efficiency of the former
%
%  prmList1/2 - prm lists instead of prm spectra (no parent mass at the end!)
%  tolerance - tolerated mass difference between matching prms 

%
%   Changelog:
%       2005/02/09: - Made sure that list of matched PRMs has no repeated PRMs for scoreFunIdx = 6 (happened when spectra included PRMs at zero and parent mass)
%                   - Removed assumption that scoreFunIdx=7 should run with 2*tolerance. Call scoreOverlapE with 2*tolerance to get the same effect
%

if tolerance<=0
    idx1 = [];   idx2 = [];  i1=1; i2=1;  prmList2(:,1) = prmList2(:,1) + shift;
    while i1<=size(prmList1,1) & i2<=size(prmList2,1)
        if prmList1(i1,1)==prmList2(i2,1) idx1 = [idx1; i1]; idx2 = [idx2; i2]; i1=i1+1; i2=i2+1; 
        else if prmList1(i1,1)<prmList2(i2,1) i1=i1+1; else i2=i2+1; end;
        end;
    end;
else
    [idx1, idx2] = sps_findMatchingPeaks(prmList1, prmList2, shift, tolerance);
end;

if size(idx1,1)==0 score=0; prmIndex={[],[]}; return; end;

prmCount = size(idx1,1);
tmpScore = zeros(3, prmCount+1);  % one more entry to initialize the algorithm
tmpScore(1,2:prmCount+1) = prmList1(idx1,2)' + prmList2(idx2,2)';
tmpScore(2,2:prmCount+1) = 1;
maxIdx = 1;
forbiddenIdx = 2;  % First prm
for i=3:(prmCount+1)
    % try to advance forbidden
    while prmList1(idx1(forbiddenIdx-1),1) <= prmList1(idx1(i-1),1)-56  % 56 instead of 57 is an implicit 1 dalton tolerance
        if tmpScore(1,forbiddenIdx) > tmpScore(1,maxIdx) maxIdx = forbiddenIdx; end;
        forbiddenIdx=forbiddenIdx+1;
    end;
    
    % simply connect to the maximal scoring available prm
    tmpScore(:,i) = [tmpScore(1,i)+tmpScore(1,maxIdx) tmpScore(2,maxIdx)+1 maxIdx]';
end;
[foo, bestIdx] = max(tmpScore(1,forbiddenIdx:(prmCount+1)));
bestIdx = forbiddenIdx + bestIdx - 1;

score = tmpScore(1,bestIdx);
finalCount = tmpScore(2,bestIdx);
idxOut1=zeros(1,finalCount); idxOut2=zeros(1,finalCount); i=0; j=bestIdx;
while j>1
    idxOut1(1,finalCount-i)=idx1(j-1);   idxOut2(1,finalCount-i)=idx2(j-1);
    j = tmpScore(3,j); i=i+1;
end;
prmIndex = {idxOut1, idxOut2};

% Add scores of matching end-points/internal PRMs - this assumes that shift aligns prefix PRMs! What if it aligns suffix PRMS?
if shift<0
    idx=find(abs(prmList2(:,1)+shift)<=tolerance);
    if ~isempty(idx) [m,idxMax]=max(prmList2(idx,2)); score=score+m; prmIndex{1,2}=[prmIndex{1,2} idx(idxMax(1))]; end;
else 
    idx=find(abs(prmList1(:,1)-shift)<=tolerance);
    if ~isempty(idx) [m,idxMax]=max(prmList1(idx,2)); score=score+m; prmIndex{1,1}=[prmIndex{1,1} idx(idxMax(1))]; end;
end;
if mhMass1-shift<mhMass2
    idx=find(abs(prmList2(:,1)-(mhMass1-19-shift))<=2*tolerance);
    if ~isempty(idx) [m,idxMax]=max(prmList2(idx,2)); score=score+m; prmIndex{1,2}=[prmIndex{1,2} idx(idxMax(1))]; end;
else    
    idx=find(abs(prmList1(:,1)-(mhMass2-19+shift))<=2*tolerance);
    if ~isempty(idx) [m,idxMax]=max(prmList1(idx,2)); score=score+m; prmIndex{1,1}=[prmIndex{1,1} idx(idxMax(1))]; end;
end  

prmIndex{1,1} = unique(prmIndex{1,1});  % Added on 2005/02/09 because of PRM spectra with PRMs at zero and parent mass (coinciding with endpoints)
prmIndex{1,2} = unique(prmIndex{1,2});
score = sum(prmList1(prmIndex{1,1},2)) + sum(prmList2(prmIndex{1,2},2));
    