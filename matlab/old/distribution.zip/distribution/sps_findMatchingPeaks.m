function [idx1, idx2] = findMatchPeaksAll(peakList1, peakList2, shift, tolerance)
%
%  Construct a list of ALL the matching peaks in the two peak lists after peakList2 is shifted by shift
%
%  Same as findMatchPeaksAll but MUCH faster
%
%  peakList1/peakList2 - lists of peaks with NO parent mass at the end
%

peakCount1 = size(peakList1,1);   peakCount2 = size(peakList2,1);
if peakCount1==0 | peakCount2==0 idx1=[]; idx2=[]; return; end;
peakList2(:,1) = peakList2(:,1) + shift;  % apply shift to peakList2

matches = abs(repmat(peakList1(:,1),1,peakCount2) - repmat(peakList2(:,1)',peakCount1,1)) - tolerance <= 1e-5;
idxMatch = find(matches==1);

if ~isempty(idxMatch)
	cols = ceil(idxMatch / peakCount1);
	lines = mod(idxMatch,peakCount1);   lines(find(lines==0))=peakCount1;
	
	idx = sortrows([lines cols]);
    idx1 = idx(:,1);   idx2 = idx(:,2);
else
    idx1=[]; idx2=[];
end
