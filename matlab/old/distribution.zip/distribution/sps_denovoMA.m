function seq = sps_denovoMA(prmLists1, prmLists2, mhMass, tolerance)

global AAmasses AAletters;
prmsB = []; prmsY = []; directionPrefix=0; enforceEndpoints=1; k=1;

if isempty(prmLists1{1,1}) | isempty(prmLists2{1,1}) 
    seq = ''; directionPrefix=0; return;
end

if ~isempty(prmLists1{1,2}) | ~isempty(prmLists1{1,3}) | ~isempty(prmLists2{1,2}) | ~isempty(prmLists2{1,3})
	for i=0:k
        if i==0 
            dir1 = matchDirection(prmLists1{1,1}, prmLists1{1,2}', prmLists1{1,3}', [], tolerance);
            dir2 = matchDirection(prmLists2{1,1}, prmLists2{1,2}', prmLists2{1,3}', [], tolerance);
        else
            [masses, letters] = getjumps(AAmasses, AAletters,i); 
            dir1 = matchDirection(prmLists1{1,1}, prmLists1{1,2}', prmLists1{1,3}', masses, tolerance);
            dir2 = matchDirection(prmLists2{1,1}, prmLists2{1,2}', prmLists2{1,3}', masses, tolerance);
        end
        if (dir1==1 & dir2<1) | (dir2==0 & dir1==-1) prmsB = prmLists1; prmsY = prmLists2; directionPrefix=1; break; end;
        if (dir2==1 & dir1<1) | (dir1==0 & dir2==-1) prmsB = prmLists2; prmsY = prmLists1; directionPrefix=2; break; end;
	end;
end

if isempty(prmsB)
    fprintf(1,'Direction unknown\n'); 
    prmsB = prmLists1;   prmsY = prmLists2;
	endPoints = [0 mhMass-19]';
    szEndPoints = 2;   dirUnknown = 1;
else
	endPoints = [0 prmsB{1,2} prmsB{1,3}-19 mhMass-prmsY{1,2}-19 mhMass-prmsY{1,3} mhMass-19]';   
    if enforceEndpoints
        endPoints = sps_weightedMerge([endPoints ones(size(endPoints))], 1, 'max');    
        endPoints = [endPoints(:,1) ones(size(endPoints,1),1)];
    end
    szEndPoints = size(endPoints,1);   dirUnknown = 0;
end

[peaksB, idx] = sort(prmsB{1,1}(:,1));           peaksB = [peaksB prmsB{1,1}(idx,2)];
[peaksY, idx] = sort(mhMass-1-prmsY{1,1}(:,1));  peaksY = [peaksY prmsY{1,1}(idx,2)];
prms = sps_weightedMerge([peaksB; peaksY], tolerance, 'sum');   maxPRMscore = max(prms(:,2));

if dirUnknown   
    tmp_endPoints = [endPoints max(prms(:,2))*ones(szEndPoints,1)];
    endPoints = [0 prmsB{1,2} prmsB{1,3}-19 mhMass-prmsY{1,2}-19 mhMass-prmsY{1,3} mhMass-19]';
    szEndPoints = size(endPoints,1);
end
if szEndPoints>0 & ~enforceEndpoints
    endPointScore = 2*max(prms(:,2))+1; 
    endPoints = sort(round(10*endPoints));    tolerance=round(10*tolerance);   minEndPoints = min(endPoints);
    endPointArray = zeros(max(endPoints)-minEndPoints+2*tolerance+1,1);
    endPointIdx = endPoints-minEndPoints+tolerance+1;
    for i=1:szEndPoints idx=endPointIdx(i); endPointArray(idx) = endPointArray(idx)+1; end;
    endPointScores = zeros(size(endPointArray));  
    for i=1:szEndPoints idx=endPointIdx(i); endPointScores(idx)=endPointScore*sum(endPointArray(idx-tolerance:idx+tolerance)); end;
    idx = find(endPointScores>0);
    endPoints = [(idx+minEndPoints-tolerance-1)/10 endPointScores(idx)];   szEndPoints = size(endPoints,1);
    tolerance = tolerance/10;
end
if dirUnknown endPoints=tmp_endPoints; szEndPoints=size(endPoints,1); clear tmp_endPoints; end;


prms = [prms zeros(size(prms,1),2)];   p=1;
for i=1:szEndPoints
    while p<=size(prms,1) & prms(p,1)<endPoints(i,1)   prms(p,4)=i;  p=p+1;  end;
    if p>size(prms,1) prms = [prms; [endPoints(i:szEndPoints,:) 1+[i:szEndPoints]' 1+[i:szEndPoints]']]; break; end;
    if abs(prms(p,1)-endPoints(i,1))<=1e-5 prms(p,:) = [[0 prms(p,2)]+endPoints(i,:) i+1 i+1]; else 
        prms = [prms(1:p-1,:); endPoints(i,:) i+1 i+1; prms(p:size(prms,1),:)];
    end;
end
if enforceEndpoints
	minRank=0; for i=1:size(prms,1) minRank=max(minRank,prms(i,3)); prms(i,4)=minRank; end;
else
    prms(:,3:4) = 0;
end

[masses, letters] = getjumps(AAmasses, AAletters, k);   
mhMass = round(mhMass*10);   masses = round(masses*10);   maxJump = max(masses);
prms(:,1) = round(prms(:,1)*10);   tolerance = round(tolerance*10);
spec = cell(mhMass,1);
for i=1:size(prms,1)
    for t=-tolerance:tolerance
        if prms(i,1)+t>0 spec{prms(i,1)+t} = [spec{prms(i,1)+t} i]; end;
    end
end

tolRange = [-tolerance:tolerance]; 
numPrms = size(prms,1);   path = [zeros(numPrms,1) prms(:,2:3)];
curRank = 0;   minRankIdx = 1; 
for i=1:size(prms,1)
    if path(i,3)<prms(i,4) path(i,2)=-1; continue; end;
    jumps = prms(i,1)+masses;    jumps = jumps(find(jumps<mhMass));
    succ = unique( [spec{jumps,1}]' );
    for j=1:size(succ,1)
        jumpRank = max(path(i,3),prms(succ(j),3));
        if jumpRank < prms(succ(j),4) | path(i,3)+1<prms(succ(j),3) continue; end;
        if path(i,2)+prms(succ(j),2)<=path(succ(j),2) continue; end;
        path(succ(j),:)=[i path(i,2)+prms(succ(j),2) jumpRank];
    end

    idx = find(path(:,3)<path(i,3) & prms(:,1)>prms(i,1)+maxJump); 
    path(idx,3) = path(i,3);  

    if path(i,3)>curRank  
        minRankIdx = i; curRank=path(i,3); 
        idx=find(prms(:,2)==curRank+1);  
        if ~isempty(idx) path(idx,1)=i; path(idx,2)=path(i,1)+prms(idx,2); end;   
    end
    
    bestSoFar = min(find(path(minRankIdx:i,2)==max(path(minRankIdx:i,2)))); 
    idx = find(prms(:,1)>prms(i,1)+maxJump & prms(:,4)<=curRank+1); 
    path(idx,1)=minRankIdx+bestSoFar-1;                             
    path(idx,2)=path(minRankIdx+bestSoFar-1,2) + prms(idx,2);       
end

seq = '';
if enforceEndpoints	p=numPrms; 
else
    p=max(find(path(:,2)==max(path(:,2))));
    if p<numPrms seq=sprintf('[%.1f]',(prms(numPrms,1)-prms(p,1))/10); end;
end;
while p>1
    if path(p,1)==0 
        maxPrm = p-1;
        prevs = find(path(1:maxPrm,3)>=path(p,3)-1);             
        bestPrev = max(find(path(prevs,2)==max(path(prevs,2))));
        path(p,1) = prevs(bestPrev);
    end
    jump = prms(p,1)-prms(path(p,1),1);   idx = find(abs(masses-jump)==min(abs(masses-jump)));  idx = idx(find(abs(masses(idx)-jump)<=tolerance));
    if ~isempty(idx) seq = strcat(letters{idx(1)},seq); else seq =  sprintf('[%.1f]%s',jump/10,seq); end;
    p = path(p,1);
end


function dir=matchDirection(prmList, prmPrefs, prmSuffs, jumps, tolerance)
idxB = []; idxY = [];
if isempty(jumps)
    idxB = findMatchPeaks(prmList, [prmPrefs; prmSuffs-19], 0, tolerance);
    idxY = findMatchPeaks(prmList, [prmPrefs+18; prmSuffs-1], 0, tolerance);
else
    szJumps = size(jumps,1);  szPrefs = size(prmPrefs,1);  szSuffs = size(prmSuffs,1);
    if ~isempty(prmPrefs) endpoints = unique(reshape(repmat(prmPrefs,2,szJumps)+[repmat(jumps',szPrefs,1);repmat(-jumps',szPrefs,1)],[],1)); else endpoints=[]; end;
    if ~isempty(prmSuffs) endpoints = unique([endpoints;reshape(repmat(prmSuffs-19,2,szJumps)+[repmat(jumps',szSuffs,1);repmat(-jumps',szSuffs,1)],[],1)]); end;
    idxB = findMatchPeaks(prmList, endpoints, 0, tolerance);
    idxY = findMatchPeaks(prmList, endpoints+18, 0, tolerance);
end;
if isempty(idxB) & isempty(idxY) | size(idxB,1)==size(idxY,1) dir=-1; return; end;
if size(idxB,1)>size(idxY,1) dir=1; else dir=0; end;

