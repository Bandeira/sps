function aligns = sps_getPairAligns(prmSpectra, tolerance, pmTol, k)

szPrmSpectra = size(prmSpectra,1);   
index1 = [1:szPrmSpectra]';   index2 = [1:szPrmSpectra]';   

aligns = [reshape(repmat(index1',szPrmSpectra,1),szPrmSpectra*szPrmSpectra,1) repmat(index2,szPrmSpectra,1)];
aligns = unique([min(aligns')' max(aligns')'],'rows');

aligns = aligns(find(aligns(:,1)~=aligns(:,2)),:);      szAlignsHalf = size(aligns,1);
aligns = reshape([aligns aligns]',2,2*szAlignsHalf)';   szAligns = size(aligns,1);
aligns = [aligns zeros(szAligns,3)];                    extraAligns = []; 

global AAmasses AAletters;
smallJumps = sps_getJumps(AAmasses, AAletters, k);   tolRange = [-tolerance:.1:tolerance];

totalTime = 0;
numPeps = szPrmSpectra;

curSpec = 0;   numStarts = 0;   
for i=0:szAlignsHalf-1
    curAlign = 2*i+1;
    if (aligns(curAlign,1)~=curSpec) 
        curSpec=aligns(curAlign,1);    numStarts = numStarts + 1;
        numPrms=size(prmSpectra{curSpec,3},1);
        fprintf(1,'Current starting spectrum %d (numPrms=%d) ',curSpec, numPrms); tic; 
    end;

    pepI = aligns(curAlign,1);             pepJ = aligns(curAlign,2);
    aaMassI = prmSpectra{pepI,5} - 19;     aaMassJ = prmSpectra{pepJ,5} - 19;

    [bestPair1, bestPair2] = sps_getPrmShiftsScore(prmSpectra{pepI,3}, prmSpectra{pepI,5}, prmSpectra{pepJ,3}, prmSpectra{pepJ,5}, tolerance, pmTol, smallJumps);

    if isempty(bestPair1)
        aligns(curAlign,:) = [pepI pepJ 0 0 0];    curAlign = curAlign+1;
        aligns(curAlign,:) = [pepJ pepI 0 0 0];    curAlign = curAlign+1;
    else
        if ~isempty(bestPair2) scoresRatio = bestPair1(1,3)/bestPair2(1,3); else scoresRatio = 0; end;
        
        zeroScore = bestPair1(find(abs(bestPair1(:,1))<=tolerance),3);   if size(zeroScore,1)>0 zeroScore = [zeroScore(1,:) scoresRatio]; end;
        toDo = bestPair1(find(abs(bestPair1(:,1))>tolerance),[1 3]);     toDo = [toDo scoresRatio*ones(size(toDo,1),1)];
        
        if ~isempty(zeroScore)
            aligns(curAlign,:) = [pepI pepJ 0 zeroScore];               curAlign = curAlign+1;
            if size(toDo,1)==0 
                aligns(curAlign,:) = [pepJ pepI 0 zeroScore];
            else
                extraAligns = [extraAligns; pepJ pepI 0 zeroScore];
            end
        end
	
        for k=1:size(toDo,1)
            if toDo(k,1)<-tolerance
                aligns(curAlign,:) = [pepJ pepI toDo(k,:).*[-1 1 1]];   curAlign = curAlign+1;
            else
                aligns(curAlign,:) = [pepI pepJ toDo(k,:)];             curAlign = curAlign+1;
            end
        end
    end
        
    if i+1==szAlignsHalf | aligns(2*(i+1)+1,1)~=curSpec 
        curToc = toc;
        totalTime = totalTime+curToc;
        fprintf(1,'- %4.2f seconds (current avg = %4.2f s / peptide)\n',curToc, totalTime/numStarts);
    end
end;
aligns = [aligns; extraAligns];

fprintf(1,'Total elapsed time = %4.2fs, average time per peptide = %4.2f\n', totalTime, totalTime/szPrmSpectra);
