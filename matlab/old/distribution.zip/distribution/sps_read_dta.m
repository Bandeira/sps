function data = sps_read_dta(filename)

data = cell(1,2);
fid = fopen(filename);  if fid<=0 fprintf(2,'ERROR: Could not open file "%s"\n',filename); return; end;

data{1,2} = fscanf(fid, '%f %f',2);
tmp = fscanf(fid, '%f %f',2)';
while size(tmp,2)==2
    data{1,1} = [data{1,1}; tmp];
    tmp = fscanf(fid, '%f %f',2)';
end;
fclose(fid);
