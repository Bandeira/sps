function [ratio1, ratio2] = sps_getMatchRatio(contigs, alignsIJ, tolerance)

contigI = contigs(alignsIJ(1,1),:);   contigJ = contigs(alignsIJ(1,2),:);   shift = alignsIJ(1,3);

ovlpI = [max(0,shift)  min( contigI{1,5}, shift+contigJ{1,5} )];   szOverlap = ovlpI(1,2)-ovlpI(1,1);
ovlpJ = [max(0,-shift) min( contigI{1,5}-shift, contigJ{1,5} )];
if alignsIJ(1,1)==alignsIJ(2,2) symShift = -alignsIJ(2,3); else symShift = alignsIJ(2,3); end; % Be sure to get the correct symmetric shift from I to J
ovlpI = [ovlpI; max(0,symShift)  min( contigI{1,5}, symShift+contigJ{1,5} )];
ovlpJ = [ovlpJ; max(0,-symShift) min( contigI{1,5}-symShift, contigJ{1,5} )];

prmsI1 = contigI{1,3}; prmsI2 = contigI{1,3}; prmsI = contigI{1,3}; 
prmsJ1 = contigJ{1,3}; prmsJ2 = contigJ{1,3}; prmsJ = contigJ{1,3};
prmsIdxOffsetI = 0; prmsIdxOffsetJ = 0; 

prmIndices = cell(1,3);
[score prmIndices{3}] = scoreOverlapE(prmsI1, contigI{1,5}, prmsJ1, contigJ{1,5}, shift, 6, tolerance);

shift = alignsIJ(2,3);
if alignsIJ(1,1)==alignsIJ(2,2)
	[score prms] = scoreOverlapE(prmsJ2, contigJ{1,5}, prmsI2, contigI{1,5}, alignsIJ(2,3), 6, tolerance);
    prmIndices{3} = {unique([prmIndices{3}{1,1} prmsIdxOffsetI+prms{1,2}]) unique([prmIndices{3}{1,2} prmsIdxOffsetJ+prms{1,1}])};
else
    [score prms] = scoreOverlapE(prmsI2, contigI{1,5}, prmsJ2, contigJ{1,5}, alignsIJ(2,3), 6, tolerance);
    prmIndices{3} = {unique([prmIndices{3}{1,1} prmsIdxOffsetI+prms{1,1}]) unique([prmIndices{3}{1,2} prmsIdxOffsetJ+prms{1,2}])};
end;

posScore1m = sum(prmsI(prmIndices{3}{1,1},2));
negScore1m = sum(prmsI(find( (prmsI(:,1)>ovlpI(1,1) & prmsI(:,1)<ovlpI(1,2)) | (prmsI(:,1)>ovlpI(2,1) & prmsI(:,1)<ovlpI(2,2)) ),2)) - posScore1m;

posScore2m = sum(prmsJ(prmIndices{3}{1,2},2));
negScore2m = sum(prmsJ(find( (prmsJ(:,1)>ovlpJ(1,1) & prmsJ(:,1)<ovlpJ(1,2)) | (prmsJ(:,1)>ovlpJ(2,1) & prmsJ(:,1)<ovlpJ(2,2)) ),2)) - posScore2m;

if negScore1m==0 ratio1 = posScore1m; else ratio1 = posScore1m/(posScore1m+negScore1m); end;
if negScore2m==0 ratio2 = posScore2m; else ratio2 = posScore2m/(posScore2m+negScore2m); end;
