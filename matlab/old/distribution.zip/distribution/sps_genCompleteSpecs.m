function prmSpecs = genPrmSpecs(contigs, vSets, minPrmScore, tolerance)
%
%  Generates the prmSpecs required for mergeConnected3 when only the contigs variable is available. This is the case when
%    peak/prm selection/scoring was performed simultaneously, e.g. by using pepnovo
%
%  contigs - scored spectra
%  vSets - as returned by filterDirection2/3 or assembleE. If it is not empty then prmSpecs are generated
%            only for those contigs that belong to some connected component
%  minPrmScore - PRM score when no supporting MS/MS spectrum peaks are present (should be negative)
%  tolerance - PRM peak tolerance
%

numSpecs = size(contigs,1);   tolRange = [-10*tolerance:10*tolerance];   szTolRange = size(tolRange,2);
prmSpecs = cell(numSpecs,1);

if isempty(vSets) idxContigs = [1:numSpecs]'; else idxContigs = [vSets{:}]'; end
szIdxContigs = size(idxContigs,1);
for i=1:szIdxContigs
    k = idxContigs(i);
    mhMass = round(10*contigs{k,5});
    prmSpecs{k,1} = [[1:mhMass]' zeros(mhMass,1)];
    
    idx = find(contigs{k,3}(:,1)>50 & contigs{k,3}(:,1)<mhMass-30);
    prms = [round(10*contigs{k,3}(idx,1)) contigs{k,3}(idx,2)];
    for j=1:szTolRange
        prmSpecs{k,1}(prms(:,1)+tolRange(j),2)=prmSpecs{k,1}(prms(:,1)+tolRange(j),2) + prms(:,2);
    end
    
    prmSpecs{k,1}(find(prmSpecs{k,1}(:,2)==0),2) = minPrmScore;
end
