function peakList = load_peaklist(filename)
%
%  Load a peaklist from a text file, 2 values per line
%

peakList = [];
fid = fopen(filename,'r');   
if (fid<=0) 
    fprintf(1,'Unable to open %s!\n', filename); 
    return; 
end;

if ~feof(fid) line=fgetl(fid); else line=''; end;
if strcmp(line(5:size(line,2)),'t initialize maps for an empty Spectrum!')==1 fclose(fid); return; end;
if strcmp(line(1:8),'Spectrum')==1 fclose(fid); return; end;
while size(line,2)>1
    [mz, intensity] = strtok(line,' ');
    peakList = [peakList; str2num(mz) str2num(intensity)];
    
    if ~feof(fid) line=fgetl(fid); else line=''; end;
end

fclose(fid);
