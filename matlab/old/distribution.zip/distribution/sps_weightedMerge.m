function newPrms = weightedMerge(prmList, tolerance, scoreType)
% function newPrms = weightedMerge(prmList, tolerance, scoreType)
%
%  Merge peaks that are tolerance Daltons away from each other. Final peak position is a weighted (intensity or score) average of initial positions
%
%

if isempty(prmList) newPrms = prmList; return; end;
[foo, idxS] = sort(prmList(:,1));
prmsS = prmList(idxS,:);
cur = 1;   newPrms = [];
for j=2:size(prmsS,1)
    if prmsS(j,1) - max(prmsS(cur,1)) <= tolerance
        cur = [cur j];
    else
        if scoreType == 'max'
            newPrms = [newPrms; sum(prmsS(cur,1).*prmsS(cur,2))/sum(prmsS(cur,2)) max(prmsS(cur,2))];
        else
            newPrms = [newPrms; sum(prmsS(cur,1).*prmsS(cur,2))/sum(prmsS(cur,2)) sum(prmsS(cur,2))];
        end
        cur = j;
    end
end
if scoreType == 'max'
    newPrms = [newPrms; sum(prmsS(cur,1).*prmsS(cur,2))/sum(prmsS(cur,2)) max(prmsS(cur,2))];
else
    newPrms = [newPrms; sum(prmsS(cur,1).*prmsS(cur,2))/sum(prmsS(cur,2)) sum(prmsS(cur,2))];
end
